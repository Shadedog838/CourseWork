export interface lesson {
  title: String;
  video: String;
}
