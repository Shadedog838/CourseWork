export interface Image {
  link: any;
}
