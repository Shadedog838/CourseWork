export interface User {
  name: string;
  email: string;
  address: string;
  userName: string;
  courses: number[];
  shoppingCart: number[];
  banned: boolean;
}
