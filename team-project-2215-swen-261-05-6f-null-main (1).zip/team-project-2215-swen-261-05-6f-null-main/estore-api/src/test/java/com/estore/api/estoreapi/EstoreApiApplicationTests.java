package com.estore.api.estoreapi;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Tag("Controller-tier")
@SpringBootTest
class EstoreApiApplicationTests {

    @Test
    void testcontextLoads() {
    }

}
